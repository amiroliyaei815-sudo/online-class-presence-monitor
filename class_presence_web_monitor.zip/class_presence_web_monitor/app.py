#!/usr/bin/env python3
"""
ناظر حضور کلاس آنلاین (نسخه وب)
Smart Online Classroom Presence Monitor - Web Version
همه چیز در یک فایل برای استقرار آسان روی Render بدون ارور
"""

import base64
import time
import threading
from datetime import datetime
from io import BytesIO

import cv2
import numpy as np
from flask import Flask, request, jsonify, render_template_string

# ──────────────────────────────────────────────────────────────────────────────
# تنظیمات
# ──────────────────────────────────────────────────────────────────────────────
ABSENCE_THRESHOLD_MINUTES = 5
ABSENCE_THRESHOLD_SECONDS = ABSENCE_THRESHOLD_MINUTES * 60
FRAME_SEND_INTERVAL_MS = 2000          # هر ۲ ثانیه یک فریم بفرست (برای مصرف کمتر)
PHOTO_DETECTION_SENSITIVITY = 0.85
MAX_STUDENTS = 50

# رنگ‌ها (برای پردازش)
COLOR_GREEN  = (0, 200, 80)
COLOR_RED    = (0, 50, 220)
COLOR_ORANGE = (0, 140, 255)

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

# تشخیص چهره
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

# وضعیت جهانی
students = {}          # name -> StudentMonitor
alerts_log = []        # لیست هشدارها
lock = threading.Lock()


# ──────────────────────────────────────────────────────────────────────────────
# کلاس تشخیص زنده بودن (بدون تغییر عمده از نسخه دسکتاپ)
# ──────────────────────────────────────────────────────────────────────────────
class FaceLivenessDetector:
    def __init__(self):
        self.prev_gray = None
        self.texture_scores = []
        self.movement_scores = []
        self.consecutive_static = 0
        self.liveness_score = 0.0

    def compute_texture_score(self, face_roi):
        if face_roi is None or face_roi.size == 0:
            return 0.0
        gray = cv2.cvtColor(face_roi, cv2.COLOR_BGR2GRAY) if len(face_roi.shape) == 3 else face_roi
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        return float(np.var(laplacian))

    def compute_motion_score(self, current_gray, face_box):
        if self.prev_gray is None or face_box is None:
            self.prev_gray = current_gray.copy()
            return 0.0
        try:
            x, y, w, h = face_box
            x1, y1 = max(0, x), max(0, y)
            x2, y2 = min(current_gray.shape[1], x + w), min(current_gray.shape[0], y + h)
            if x2 <= x1 or y2 <= y1:
                return 0.0
            curr_roi = current_gray[y1:y2, x1:x2]
            prev_roi = self.prev_gray[y1:y2, x1:x2]
            if curr_roi.shape != prev_roi.shape or curr_roi.size == 0:
                return 0.0
            diff = cv2.absdiff(curr_roi, prev_roi)
            motion = float(np.mean(diff))
            return motion
        except Exception:
            return 0.0
        finally:
            self.prev_gray = current_gray.copy()

    def analyze_frame(self, frame, face_box):
        result = {
            "is_live": False,
            "score": 0.0,
            "texture_score": 0.0,
            "motion_score": 0.0,
            "reason": ""
        }
        if frame is None or face_box is None:
            result["reason"] = "no_face"
            return result

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        x, y, w, h = face_box

        # امتیاز بافت
        x1, y1 = max(0, x), max(0, y)
        x2, y2 = min(frame.shape[1], x + w), min(frame.shape[0], y + h)
        face_roi = frame[y1:y2, x1:x2]
        texture = self.compute_texture_score(face_roi)
        result["texture_score"] = texture
        self.texture_scores.append(texture)
        if len(self.texture_scores) > 25:
            self.texture_scores.pop(0)

        # امتیاز حرکت
        motion = self.compute_motion_score(gray, face_box)
        result["motion_score"] = motion
        self.movement_scores.append(motion)
        if len(self.movement_scores) > 40:
            self.movement_scores.pop(0)

        avg_motion = np.mean(self.movement_scores[-15:]) if self.movement_scores else 0
        avg_texture = np.mean(self.texture_scores[-8:]) if self.texture_scores else 0

        texture_norm = min(1.0, avg_texture / 75.0)
        motion_norm = min(1.0, avg_motion / 2.8)

        combined_score = 0.4 * texture_norm + 0.6 * motion_norm
        result["score"] = round(combined_score, 3)
        self.liveness_score = combined_score

        if combined_score >= PHOTO_DETECTION_SENSITIVITY * 0.55:
            result["is_live"] = True
            result["reason"] = "natural_movement_or_texture"
        elif motion_norm > 0.35:
            result["is_live"] = True
            result["reason"] = "motion_detected"
        elif texture_norm > 0.65:
            result["is_live"] = True
            result["reason"] = "high_texture"
        else:
            result["is_live"] = False
            result["reason"] = "static_or_photo"

        if not result["is_live"]:
            self.consecutive_static += 1
        else:
            self.consecutive_static = max(0, self.consecutive_static - 2)

        if self.consecutive_static > 25:
            result["is_live"] = False
            result["score"] = 0.0
            result["reason"] = "confirmed_photo_or_absent"

        return result


# ──────────────────────────────────────────────────────────────────────────────
# کلاس مانیتور دانش‌آموز (وب)
# ──────────────────────────────────────────────────────────────────────────────
class StudentMonitor:
    def __init__(self, student_name):
        self.student_name = student_name
        self.is_present = False
        self.last_seen_time = None
        self.absence_start_time = None
        self.absence_duration = 0.0
        self.alert_sent = False
        self.total_absence_seconds = 0.0
        self.liveness_detector = FaceLivenessDetector()
        self.last_update = time.time()
        self.last_face_detected = False
        self.last_is_live = False
        self.last_liveness_score = 0.0

    def update_presence(self, face_detected, is_live, liveness_score):
        now = time.time()
        now_dt = datetime.now()
        self.last_update = now
        self.last_face_detected = face_detected
        self.last_is_live = is_live
        self.last_liveness_score = liveness_score

        actually_present = face_detected and is_live

        if actually_present:
            if not self.is_present:
                if self.absence_start_time:
                    absence_dur = now - self.absence_start_time
                    self.total_absence_seconds += absence_dur
                self.alert_sent = False
            self.is_present = True
            self.last_seen_time = now
            self.absence_start_time = None
            self.absence_duration = 0.0
        else:
            if self.is_present:
                self.absence_start_time = now
            self.is_present = False
            if self.absence_start_time:
                self.absence_duration = now - self.absence_start_time

                # هشدار ۵ دقیقه
                if (self.absence_duration >= ABSENCE_THRESHOLD_SECONDS and not self.alert_sent):
                    self.alert_sent = True
                    alert_info = {
                        "student": self.student_name,
                        "absence_minutes": round(self.absence_duration / 60, 1),
                        "last_seen": datetime.fromtimestamp(self.last_seen_time).strftime("%H:%M:%S")
                                     if self.last_seen_time else "نامشخص",
                        "time": now_dt.strftime("%H:%M:%S"),
                        "face_detected": face_detected,
                        "is_live": is_live
                    }
                    with lock:
                        alerts_log.append(alert_info)
                        # فقط ۳۰ هشدار آخر نگه دار
                        if len(alerts_log) > 30:
                            alerts_log.pop(0)

    def get_status(self):
        now = time.time()
        # اگر بیش از ۴۰ ثانیه فریم نفرستاده → غایب محسوب کن
        if now - self.last_update > 40 and self.is_present:
            self.is_present = False
            if self.absence_start_time is None:
                self.absence_start_time = now

        if self.absence_start_time and not self.is_present:
            self.absence_duration = now - self.absence_start_time

        return {
            "name": self.student_name,
            "is_present": self.is_present,
            "absence_seconds": round(self.absence_duration, 1),
            "alert_sent": self.alert_sent,
            "total_absence_minutes": round(self.total_absence_seconds / 60, 1),
            "liveness_score": round(self.last_liveness_score, 2),
            "last_face_detected": self.last_face_detected,
            "last_is_live": self.last_is_live,
            "last_update": datetime.fromtimestamp(self.last_update).strftime("%H:%M:%S")
        }


# ──────────────────────────────────────────────────────────────────────────────
# APIها
# ──────────────────────────────────────────────────────────────────────────────
@app.route('/api/update', methods=['POST'])
def api_update():
    data = request.get_json(silent=True) or {}
    name = (data.get('name') or 'دانش‌آموز ناشناس').strip()[:40]
    frame_b64 = data.get('frame')

    with lock:
        if name not in students:
            if len(students) >= MAX_STUDENTS:
                return jsonify({"error": "تعداد دانش‌آموزان بیش از حد مجاز است"}), 429
            students[name] = StudentMonitor(name)

        monitor = students[name]

        face_detected = False
        is_live = False
        liveness_score = 0.0

        if frame_b64:
            try:
                # حذف header base64 اگر باشد
                if ',' in frame_b64:
                    frame_b64 = frame_b64.split(',')[1]
                img_bytes = base64.b64decode(frame_b64)
                nparr = np.frombuffer(img_bytes, np.uint8)
                frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

                if frame is not None:
                    # تشخیص چهره
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                    gray_eq = cv2.equalizeHist(gray)
                    faces = face_cascade.detectMultiScale(
                        gray_eq, scaleFactor=1.1, minNeighbors=5,
                        minSize=(70, 70), flags=cv2.CASCADE_SCALE_IMAGE
                    )
                    face_detected = len(faces) > 0

                    if face_detected:
                        # بزرگ‌ترین چهره
                        areas = [w * h for (x, y, w, h) in faces]
                        best_idx = int(np.argmax(areas))
                        face_box = tuple(faces[best_idx])
                        liveness_result = monitor.liveness_detector.analyze_frame(frame, face_box)
                        is_live = liveness_result["is_live"]
                        liveness_score = liveness_result["score"]
            except Exception as e:
                print(f"[ERROR] پردازش فریم: {e}")

        monitor.update_presence(face_detected, is_live, liveness_score)
        status = monitor.get_status()

    return jsonify({
        "success": True,
        "status": status
    })


@app.route('/api/status', methods=['GET'])
def api_status():
    with lock:
        student_list = [m.get_status() for m in students.values()]
        # مرتب‌سازی: حاضرها اول
        student_list.sort(key=lambda x: (not x["is_present"], x["name"]))

        recent_alerts = alerts_log[-12:][::-1]  # جدیدترین اول

    return jsonify({
        "students": student_list,
        "alerts": recent_alerts,
        "total_students": len(student_list),
        "present_count": sum(1 for s in student_list if s["is_present"]),
        "server_time": datetime.now().strftime("%H:%M:%S")
    })


@app.route('/api/clear_alerts', methods=['POST'])
def api_clear_alerts():
    with lock:
        alerts_log.clear()
    return jsonify({"success": True, "message": "لاگ هشدارها پاک شد"})


# ──────────────────────────────────────────────────────────────────────────────
# رابط کاربری کامل (HTML + Tailwind + JS) - یکجا برای سادگی
# ──────────────────────────────────────────────────────────────────────────────
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎓 ناظر حضور کلاس آنلاین | Smart Classroom Monitor</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700&amp;display=swap');
        body { font-family: 'Vazirmatn', system-ui, -apple-system, sans-serif; }
        .glass { background: rgba(255,255,255,0.08); backdrop-filter: blur(12px); }
        .status-dot { animation: pulse 2s infinite; }
        .student-card { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .alert-row { animation: fadeIn 0.4s ease; }
        video { border-radius: 12px; box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.3); }
        .nav-active { border-bottom: 3px solid #22c55e; color: #22c55e; }
        .metric { transition: transform 0.2s ease; }
        .metric:hover { transform: translateY(-2px); }
    </style>
</head>
<body class="bg-zinc-950 text-zinc-200">
    <!-- هدر -->
    <div class="border-b border-zinc-800 bg-zinc-900/80 backdrop-blur-lg sticky top-0 z-50">
        <div class="max-w-screen-xl mx-auto px-6 py-4 flex items-center justify-between">
            <div class="flex items-center gap-x-3">
                <div class="w-11 h-11 bg-emerald-600 rounded-2xl flex items-center justify-center">
                    <i class="fa-solid fa-graduation-cap text-white text-3xl"></i>
                </div>
                <div>
                    <h1 class="text-2xl font-bold tracking-tight">ناظر حضور کلاس آنلاین</h1>
                    <p class="text-xs text-zinc-500 -mt-1">Smart Classroom Presence Monitor</p>
                </div>
            </div>
            <div class="flex items-center gap-x-2 text-sm">
                <div class="px-3 py-1.5 bg-zinc-900 rounded-2xl flex items-center gap-x-2 border border-zinc-800">
                    <div class="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                    <span class="text-emerald-400 text-xs font-medium">آنلاین • Render Ready</span>
                </div>
                <div onclick="showHome()" 
                     class="cursor-pointer px-4 py-1.5 hover:bg-zinc-800 rounded-2xl flex items-center gap-x-2 text-sm transition-colors">
                    <i class="fa-solid fa-home"></i>
                    <span>خانه</span>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-screen-xl mx-auto px-6 pt-8 pb-12">
        
        <!-- صفحه اصلی (انتخاب نقش) -->
        <div id="home-view">
            <div class="text-center mb-10">
                <h2 class="text-4xl font-bold tracking-tighter mb-3">به سیستم نظارت هوشمند خوش آمدید</h2>
                <p class="text-zinc-400 max-w-md mx-auto">لطفاً نقش خود را انتخاب کنید. معلم هیچ تصویری از دانش‌آموز نمی‌بیند.</p>
            </div>

            <div class="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto">
                <!-- کارت دانش‌آموز -->
                <div onclick="showStudentPanel()" 
                     class="group cursor-pointer bg-zinc-900 border border-zinc-800 hover:border-emerald-600/70 rounded-3xl p-8 transition-all active:scale-[0.985]">
                    <div class="flex items-center gap-x-4 mb-6">
                        <div class="w-14 h-14 bg-emerald-600/10 text-emerald-500 rounded-2xl flex items-center justify-center group-hover:bg-emerald-600/20 transition-colors">
                            <i class="fa-solid fa-user-graduate text-3xl"></i>
                        </div>
                        <div>
                            <div class="font-bold text-2xl">دانش‌آموز</div>
                            <div class="text-emerald-400 text-sm">پنل ارسال تصویر</div>
                        </div>
                    </div>
                    <p class="text-zinc-400 leading-relaxed">دوربین خود را روشن کنید. سیستم به صورت خودکار حضور شما را تشخیص می‌دهد و در صورت غیبت طولانی به معلم اطلاع می‌دهد.</p>
                    <div class="mt-8 flex items-center text-emerald-500 font-medium text-sm group-hover:gap-x-2 transition-all">
                        <span>ورود به پنل دانش‌آموز</span>
                        <i class="fa-solid fa-arrow-left mr-2"></i>
                    </div>
                </div>

                <!-- کارت معلم -->
                <div onclick="showTeacherPanel()" 
                     class="group cursor-pointer bg-zinc-900 border border-zinc-800 hover:border-amber-600/70 rounded-3xl p-8 transition-all active:scale-[0.985]">
                    <div class="flex items-center gap-x-4 mb-6">
                        <div class="w-14 h-14 bg-amber-600/10 text-amber-500 rounded-2xl flex items-center justify-center group-hover:bg-amber-600/20 transition-colors">
                            <i class="fa-solid fa-chalkboard-teacher text-3xl"></i>
                        </div>
                        <div>
                            <div class="font-bold text-2xl">معلم / مدیر</div>
                            <div class="text-amber-400 text-sm">داشبورد نظارت</div>
                        </div>
                    </div>
                    <p class="text-zinc-400 leading-relaxed">وضعیت لحظه‌ای تمام دانش‌آموزان، مدت غیبت و هشدارهای خودکار را مشاهده کنید. تصویر چهره نمایش داده نمی‌شود.</p>
                    <div class="mt-8 flex items-center text-amber-500 font-medium text-sm group-hover:gap-x-2 transition-all">
                        <span>ورود به داشبورد معلم</span>
                        <i class="fa-solid fa-arrow-left mr-2"></i>
                    </div>
                </div>
            </div>

            <div class="text-center mt-10 text-xs text-zinc-500">
                آستانه غیبت: <span class="font-mono text-emerald-400">۵ دقیقه</span> • تشخیص زنده بودن فعال • حریم خصوصی کامل
            </div>
        </div>

        <!-- پنل دانش‌آموز -->
        <div id="student-view" class="hidden max-w-2xl mx-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h3 class="text-3xl font-bold">پنل دانش‌آموز</h3>
                    <p class="text-zinc-400">دوربین را روشن کنید تا حضور شما ثبت شود</p>
                </div>
                <button onclick="showHome()" 
                        class="px-5 py-2 text-sm bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 rounded-2xl flex items-center gap-x-2">
                    <i class="fa-solid fa-arrow-right"></i>
                    <span>بازگشت</span>
                </button>
            </div>

            <div class="bg-zinc-900 border border-zinc-800 rounded-3xl p-8">
                <!-- نام -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-zinc-400 mb-2">نام / نام کاربری</label>
                    <input id="student-name" type="text" value="دانش‌آموز ۱" 
                           class="w-full bg-zinc-950 border border-zinc-700 focus:border-emerald-600 rounded-2xl px-5 py-3 text-lg outline-none">
                </div>

                <!-- ویدیو -->
                <div class="relative mb-6 bg-black rounded-2xl overflow-hidden aspect-video flex items-center justify-center" id="video-container">
                    <video id="video" autoplay playsinline muted class="w-full h-full object-cover scale-x-[-1]"></video>
                    <div id="video-placeholder" 
                         class="absolute inset-0 flex flex-col items-center justify-center bg-zinc-950/80 text-center px-6">
                        <i class="fa-solid fa-video text-6xl text-zinc-700 mb-4"></i>
                        <p class="text-zinc-400">دوربین خاموش است</p>
                    </div>
                </div>

                <!-- وضعیت -->
                <div class="grid grid-cols-3 gap-4 mb-6">
                    <div class="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-center">
                        <div class="text-xs text-zinc-500 mb-1">وضعیت</div>
                        <div id="student-status" class="font-bold text-xl text-zinc-400">غیرفعال</div>
                    </div>
                    <div class="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-center">
                        <div class="text-xs text-zinc-500 mb-1">امتیاز زنده بودن</div>
                        <div id="student-liveness" class="font-mono text-3xl font-bold text-emerald-400">—</div>
                    </div>
                    <div class="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-center">
                        <div class="text-xs text-zinc-500 mb-1">آخرین ارسال</div>
                        <div id="student-last-send" class="font-mono text-xl font-bold text-zinc-300">—</div>
                    </div>
                </div>

                <!-- دکمه‌ها -->
                <div class="flex gap-3">
                    <button id="start-btn"
                            onclick="startCameraAndMonitoring()"
                            class="flex-1 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 transition-colors text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-x-3 text-lg">
                        <i class="fa-solid fa-play mr-1"></i>
                        <span>شروع دوربین و نظارت</span>
                    </button>
                    <button id="stop-btn" onclick="stopCameraAndMonitoring()"
                            class="flex-1 hidden bg-red-600 hover:bg-red-500 text-white font-bold py-4 rounded-2xl items-center justify-center gap-x-3 text-lg">
                        <i class="fa-solid fa-stop mr-1"></i>
                        <span>توقف</span>
                    </button>
                </div>

                <div class="mt-4 text-center text-xs text-zinc-500">
                    فریم‌ها هر ۲ ثانیه به سرور ارسال می‌شوند • حریم خصوصی حفظ می‌شود
                </div>
            </div>
        </div>

        <!-- پنل معلم -->
        <div id="teacher-view" class="hidden">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h3 class="text-3xl font-bold">داشبورد معلم</h3>
                    <p class="text-zinc-400">وضعیت لحظه‌ای دانش‌آموزان (بدون نمایش تصویر)</p>
                </div>
                <div class="flex items-center gap-x-3">
                    <button onclick="refreshTeacherData()" 
                            class="px-6 py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 rounded-2xl flex items-center gap-x-2 text-sm font-medium">
                        <i class="fa-solid fa-sync-alt"></i>
                        <span>به‌روزرسانی</span>
                    </button>
                    <button onclick="clearAlerts()" 
                            class="px-5 py-2.5 bg-red-900/30 hover:bg-red-900/50 text-red-400 border border-red-800/60 rounded-2xl flex items-center gap-x-2 text-sm font-medium">
                        <i class="fa-solid fa-trash"></i>
                        <span>پاک کردن هشدارها</span>
                    </button>
                    <button onclick="showHome()" 
                            class="px-5 py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 rounded-2xl flex items-center gap-x-2 text-sm">
                        <i class="fa-solid fa-home"></i>
                    </button>
                </div>
            </div>

            <!-- آمار سریع -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div class="metric bg-zinc-900 border border-zinc-800 rounded-3xl p-5">
                    <div class="flex justify-between items-start">
                        <div>
                            <div class="text-emerald-400 text-sm">حاضر</div>
                            <div id="present-count" class="text-5xl font-bold tabular-nums mt-1">0</div>
                        </div>
                        <i class="fa-solid fa-check-circle text-emerald-500 text-3xl mt-1"></i>
                    </div>
                </div>
                <div class="metric bg-zinc-900 border border-zinc-800 rounded-3xl p-5">
                    <div class="flex justify-between items-start">
                        <div>
                            <div class="text-red-400 text-sm">غایب</div>
                            <div id="absent-count" class="text-5xl font-bold tabular-nums mt-1">0</div>
                        </div>
                        <i class="fa-solid fa-user-slash text-red-500 text-3xl mt-1"></i>
                    </div>
                </div>
                <div class="metric bg-zinc-900 border border-zinc-800 rounded-3xl p-5">
                    <div class="flex justify-between items-start">
                        <div>
                            <div class="text-amber-400 text-sm">هشدار فعال</div>
                            <div id="alert-count" class="text-5xl font-bold tabular-nums mt-1">0</div>
                        </div>
                        <i class="fa-solid fa-bell text-amber-500 text-3xl mt-1"></i>
                    </div>
                </div>
                <div class="metric bg-zinc-900 border border-zinc-800 rounded-3xl p-5">
                    <div class="flex justify-between items-start">
                        <div>
                            <div class="text-zinc-400 text-sm">کل دانش‌آموزان</div>
                            <div id="total-count" class="text-5xl font-bold tabular-nums mt-1">0</div>
                        </div>
                        <i class="fa-solid fa-users text-zinc-400 text-3xl mt-1"></i>
                    </div>
                </div>
            </div>

            <!-- جدول دانش‌آموزان -->
            <div class="bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/50">
                    <div class="font-semibold flex items-center gap-x-2">
                        <i class="fa-solid fa-list-check"></i>
                        <span>لیست دانش‌آموزان</span>
                    </div>
                    <div class="text-xs text-zinc-500" id="last-refresh">آخرین به‌روزرسانی: —</div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="border-b border-zinc-800 bg-zinc-950/60 text-zinc-400 text-xs">
                                <th class="text-right px-6 py-4 font-medium">نام دانش‌آموز</th>
                                <th class="text-center px-4 py-4 font-medium">وضعیت</th>
                                <th class="text-center px-4 py-4 font-medium">مدت غیبت</th>
                                <th class="text-center px-4 py-4 font-medium">زنده بودن</th>
                                <th class="text-center px-4 py-4 font-medium">آخرین ارسال</th>
                            </tr>
                        </thead>
                        <tbody id="students-table" class="divide-y divide-zinc-800 text-sm">
                            <!-- پر می‌شود با JS -->
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- لاگ هشدارها -->
            <div class="bg-zinc-900 border border-zinc-800 rounded-3xl p-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="font-semibold flex items-center gap-x-2 text-red-400">
                        <i class="fa-solid fa-bell"></i>
                        <span>لاگ هشدارهای غیبت</span>
                    </div>
                    <div class="text-xs px-3 py-1 bg-red-950 text-red-400 rounded-2xl" id="alerts-header">۰ مورد</div>
                </div>
                <div id="alerts-list" class="space-y-2 max-h-[280px] overflow-auto pr-2 text-sm">
                    <!-- هشدارها با JS پر می‌شوند -->
                </div>
                <div id="no-alerts" class="text-center py-8 text-zinc-500 text-sm hidden">
                    هنوز هیچ هشداری ثبت نشده است
                </div>
            </div>
        </div>

    </div>

    <footer class="text-center text-xs text-zinc-600 pb-8">
        ساخته شده برای کلاس‌های آنلاین • تشخیص چهره + زنده بودن • حریم خصوصی کامل
    </footer>

    <script>
        // Tailwind script
        function initTailwind() {
            document.documentElement.style.setProperty('--accent', '#22c55e');
        }

        let currentInterval = null;
        let videoStream = null;
        let isMonitoring = false;
        let lastAlertCount = 0;

        function showHome() {
            document.getElementById('home-view').classList.remove('hidden');
            document.getElementById('student-view').classList.add('hidden');
            document.getElementById('teacher-view').classList.add('hidden');
            stopCameraAndMonitoring();
        }

        function showStudentPanel() {
            document.getElementById('home-view').classList.add('hidden');
            document.getElementById('student-view').classList.remove('hidden');
            document.getElementById('teacher-view').classList.add('hidden');
        }

        function showTeacherPanel() {
            document.getElementById('home-view').classList.add('hidden');
            document.getElementById('student-view').classList.add('hidden');
            document.getElementById('teacher-view').classList.remove('hidden');
            refreshTeacherData();
            // شروع polling خودکار
            if (window.teacherInterval) clearInterval(window.teacherInterval);
            window.teacherInterval = setInterval(refreshTeacherData, 4500);
        }

        // ==================== دانش‌آموز ====================
        async function startCameraAndMonitoring() {
            const nameInput = document.getElementById('student-name');
            const name = nameInput.value.trim() || 'دانش‌آموز';
            nameInput.disabled = true;

            const video = document.getElementById('video');
            const placeholder = document.getElementById('video-placeholder');
            const startBtn = document.getElementById('start-btn');
            const stopBtn = document.getElementById('stop-btn');

            try {
                videoStream = await navigator.mediaDevices.getUserMedia({ 
                    video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } } 
                });
                video.srcObject = videoStream;
                placeholder.style.display = 'none';
                video.style.display = 'block';

                startBtn.classList.add('hidden');
                stopBtn.classList.remove('hidden');
                stopBtn.classList.add('flex');

                isMonitoring = true;
                updateStudentLocalStatus('در حال ارسال فریم‌ها...', true);

                // ارسال فریم هر ۲ ثانیه
                if (currentInterval) clearInterval(currentInterval);
                currentInterval = setInterval(() => {
                    if (!isMonitoring || !video.srcObject) return;
                    captureAndSendFrame(name, video);
                }, 2000);

                // ارسال فریم اول بلافاصله
                setTimeout(() => captureAndSendFrame(name, video), 600);

            } catch (err) {
                alert('خطا در دسترسی به دوربین: ' + err.message + '\\n\\nلطفاً اجازه دوربین را بدهید و صفحه را رفرش کنید.');
                nameInput.disabled = false;
            }
        }

        function captureAndSendFrame(name, video) {
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth || 640;
            canvas.height = video.videoHeight || 480;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

            // کیفیت پایین برای مصرف کمتر پهنای باند
            const frameData = canvas.toDataURL('image/jpeg', 0.55);

            fetch('/api/update', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: name, frame: frameData })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success && data.status) {
                    const s = data.status;
                    updateStudentLocalStatusFromServer(s);
                }
            })
            .catch(err => {
                console.warn('ارسال فریم ناموفق:', err);
            });
        }

        function updateStudentLocalStatus(text, isActive = false) {
            const statusEl = document.getElementById('student-status');
            statusEl.innerHTML = text;
            statusEl.className = isActive 
                ? 'font-bold text-xl text-emerald-400' 
                : 'font-bold text-xl text-zinc-400';
        }

        function updateStudentLocalStatusFromServer(status) {
            const statusEl = document.getElementById('student-status');
            const livenessEl = document.getElementById('student-liveness');
            const lastSendEl = document.getElementById('student-last-send');

            lastSendEl.textContent = status.last_update || '—';

            if (status.is_present && status.last_is_live) {
                statusEl.innerHTML = '● حاضر و زنده';
                statusEl.className = 'font-bold text-xl text-emerald-400';
                livenessEl.innerHTML = (status.liveness_score * 100).toFixed(0) + '%';
                livenessEl.className = 'font-mono text-3xl font-bold text-emerald-400';
            } else if (status.last_face_detected && !status.last_is_live) {
                statusEl.innerHTML = '⚠ احتمالاً عکس';
                statusEl.className = 'font-bold text-xl text-amber-400';
                livenessEl.innerHTML = (status.liveness_score * 100).toFixed(0) + '%';
                livenessEl.className = 'font-mono text-3xl font-bold text-amber-400';
            } else {
                statusEl.innerHTML = '● غایب';
                statusEl.className = 'font-bold text-xl text-red-400';
                livenessEl.innerHTML = '—';
                livenessEl.className = 'font-mono text-3xl font-bold text-zinc-400';
            }
        }

        function stopCameraAndMonitoring() {
            const video = document.getElementById('video');
            const placeholder = document.getElementById('video-placeholder');
            const startBtn = document.getElementById('start-btn');
            const stopBtn = document.getElementById('stop-btn');
            const nameInput = document.getElementById('student-name');

            if (currentInterval) {
                clearInterval(currentInterval);
                currentInterval = null;
            }
            if (videoStream) {
                videoStream.getTracks().forEach(track => track.stop());
                videoStream = null;
            }
            video.style.display = 'none';
            placeholder.style.display = 'flex';
            video.srcObject = null;

            startBtn.classList.remove('hidden');
            stopBtn.classList.add('hidden');
            stopBtn.classList.remove('flex');

            nameInput.disabled = false;
            isMonitoring = false;

            updateStudentLocalStatus('توقف شد', false);
            document.getElementById('student-liveness').innerHTML = '—';
            document.getElementById('student-last-send').innerHTML = '—';
        }

        // ==================== معلم ====================
        async function refreshTeacherData() {
            try {
                const res = await fetch('/api/status');
                const data = await res.json();

                // آمار
                document.getElementById('present-count').textContent = data.present_count || 0;
                document.getElementById('absent-count').textContent = (data.total_students || 0) - (data.present_count || 0);
                document.getElementById('total-count').textContent = data.total_students || 0;
                document.getElementById('alert-count').textContent = data.alerts ? data.alerts.length : 0;

                // جدول
                const tbody = document.getElementById('students-table');
                tbody.innerHTML = '';

                if (data.students && data.students.length > 0) {
                    data.students.forEach(s => {
                        const row = document.createElement('tr');
                        row.className = 'hover:bg-zinc-950/60 transition-colors';

                        let statusHTML = '';
                        if (s.is_present && s.last_is_live) {
                            statusHTML = `<span class="inline-flex items-center px-3 py-1 rounded-2xl text-xs font-bold bg-emerald-500/10 text-emerald-400"><i class="fa-solid fa-check mr-1.5"></i> حاضر و زنده</span>`;
                        } else if (s.last_face_detected && !s.last_is_live) {
                            statusHTML = `<span class="inline-flex items-center px-3 py-1 rounded-2xl text-xs font-bold bg-amber-500/10 text-amber-400"><i class="fa-solid fa-exclamation-triangle mr-1.5"></i> احتمال عکس</span>`;
                        } else {
                            statusHTML = `<span class="inline-flex items-center px-3 py-1 rounded-2xl text-xs font-bold bg-red-500/10 text-red-400"><i class="fa-solid fa-times mr-1.5"></i> غایب</span>`;
                        }

                        let absenceText = s.absence_seconds > 0 ? 
                            `${Math.floor(s.absence_seconds/60)}:${String(Math.floor(s.absence_seconds%60)).padStart(2,'0')}` : '—';

                        let liveHTML = s.liveness_score > 0 ? 
                            `<span class="font-mono">${(s.liveness_score*100).toFixed(0)}%</span>` : '—';

                        row.innerHTML = `
                            <td class="px-6 py-4 font-medium">${s.name}</td>
                            <td class="px-4 py-4 text-center">${statusHTML}</td>
                            <td class="px-4 py-4 text-center font-mono text-red-400">${absenceText}</td>
                            <td class="px-4 py-4 text-center">${liveHTML}</td>
                            <td class="px-4 py-4 text-center text-xs text-zinc-400 font-mono">${s.last_update}</td>
                        `;
                        tbody.appendChild(row);
                    });
                } else {
                    tbody.innerHTML = `<tr><td colspan="5" class="px-6 py-8 text-center text-zinc-500">هنوز هیچ دانش‌آموزی متصل نشده است</td></tr>`;
                }

                // هشدارها
                renderAlerts(data.alerts || []);
                document.getElementById('last-refresh').textContent = `آخرین به‌روزرسانی: ${data.server_time || ''}`;

                // نوتیفیکیشن جدید
                if (data.alerts && data.alerts.length > lastAlertCount) {
                    const newAlerts = data.alerts.length - lastAlertCount;
                    showToast(`🔔 ${newAlerts} هشدار جدید غیبت!`, true);
                    lastAlertCount = data.alerts.length;
                }
            } catch (e) {
                console.error('خطا در دریافت وضعیت:', e);
            }
        }

        function renderAlerts(alerts) {
            const container = document.getElementById('alerts-list');
            const noAlerts = document.getElementById('no-alerts');
            const header = document.getElementById('alerts-header');

            container.innerHTML = '';
            header.textContent = `${alerts.length} مورد`;

            if (!alerts.length) {
                noAlerts.classList.remove('hidden');
                return;
            }
            noAlerts.classList.add('hidden');

            alerts.forEach(a => {
                const div = document.createElement('div');
                div.className = `alert-row flex items-start gap-x-4 bg-red-950/30 border border-red-900/50 rounded-2xl px-5 py-3.5 text-sm`;
                div.innerHTML = `
                    <div class="mt-0.5"><i class="fa-solid fa-exclamation-circle text-red-500"></i></div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between">
                            <span class="font-bold text-red-300">${a.student}</span>
                            <span class="font-mono text-xs text-red-400/70">${a.time}</span>
                        </div>
                        <div class="text-red-300/90 mt-0.5">
                            غیبت ${a.absence_minutes} دقیقه • آخرین حضور: ${a.last_seen}
                            ${a.face_detected && !a.is_live ? '<span class="text-amber-400 text-xs">(چهره اما احتمالاً عکس)</span>' : ''}
                        </div>
                    </div>
                `;
                container.appendChild(div);
            });
        }

        function clearAlerts() {
            if (!confirm('آیا از پاک کردن تمام هشدارها مطمئن هستید؟')) return;
            fetch('/api/clear_alerts', { method: 'POST' })
                .then(() => {
                    document.getElementById('alerts-list').innerHTML = '';
                    document.getElementById('no-alerts').classList.remove('hidden');
                    document.getElementById('alert-count').textContent = '0';
                    document.getElementById('alerts-header').textContent = '۰ مورد';
                    showToast('هشدارها پاک شدند');
                });
        }

        function showToast(message, isAlert = false) {
            const toast = document.createElement('div');
            toast.className = `fixed bottom-6 left-1/2 -translate-x-1/2 px-6 py-3 rounded-2xl shadow-xl text-sm flex items-center gap-x-3 z-[100] ${isAlert ? 'bg-red-600 text-white' : 'bg-zinc-800 text-white border border-zinc-700'}`;
            toast.innerHTML = `
                <span>${message}</span>
                <button class="ml-4 text-xs opacity-70 hover:opacity-100">✕</button>
            `;
            document.body.appendChild(toast);
            toast.querySelector('button').onclick = () => toast.remove();
            setTimeout(() => {
                if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, isAlert ? 6500 : 2800);
        }

        // شروع اولیه
        function init() {
            initTailwind();
            // اگر کسی مستقیم لینک معلم را باز کرد
            // می‌توانیم بعداً پارامتر اضافه کنیم
            console.log('%c[ClassMonitor] Web version initialized successfully', 'color:#3f3f46');
        }

        window.onload = init;
    </script>
</body>
</html>
"""


@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)


# ──────────────────────────────────────────────────────────────────────────────
# اجرا
# ──────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    print("=" * 65)
    print("  🎓 ناظر حضور کلاس آنلاین - نسخه وب (Render Ready)")
    print(f"  آستانه غیبت: {ABSENCE_THRESHOLD_MINUTES} دقیقه")
    print("  اجرا روی: http://127.0.0.1:5000")
    print("=" * 65)
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
